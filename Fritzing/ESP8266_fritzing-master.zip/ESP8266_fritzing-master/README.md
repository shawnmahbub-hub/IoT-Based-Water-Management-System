ESP8266_fritzing
================

Fritzing part for an ESP8266-based WiFi module
